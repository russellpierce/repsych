repsych
=======

R Function for Reproducible Research in Psychology

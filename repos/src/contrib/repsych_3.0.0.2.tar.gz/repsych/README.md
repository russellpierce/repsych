repsych
=======

R Function for Reproducible Research in Psychology

To install... log in to github, then try: `install.packages("repsych",repos="https://raw.github.com/drknexus/repsych/master/repos",type="source")`
